import UIKit
import PlaygroundSupport

let backgroundView = UIView()
backgroundView.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)

PlaygroundPage.current.liveView = backgroundView
let a = PlaygroundPage.current.liveView.debugDescription

let livePageScreenCompactSize = CGSize(width: 432, height: 569)
let livePageCenter = CGPoint(x:livePageScreenCompactSize.width/2, y: livePageScreenCompactSize.height/2)
let squareSide: CGFloat = 90
let steps = 600


for i in 1 ... steps {
    let square = UIView(frame:CGRect(origin: CGPoint(x:0, y:0), size: CGSize(width: squareSide, height: squareSide)))
    square.layer.cornerRadius = squareSide/2
    
    let radius = Double(i)/1.5
    let angle = M_PI/60 * Double(i)
    let x = CGFloat(radius * cos(angle))
    let y = CGFloat(radius * sin(angle))
    let center = CGPoint(x: x + livePageCenter.x, y: y + livePageCenter.y)
    square.center = center
    square.alpha = 0
    square.backgroundColor = UIColor(hue: CGFloat(radius/Double(steps)), saturation: 0.8, brightness: 1, alpha: 1)
    backgroundView.addSubview(square)
}

for (index, view) in backgroundView.subviews.enumerated() {
    UIView.animate(withDuration: 0.1, delay: Double(index)/100, options: UIViewAnimationOptions.curveEaseOut, animations: {
    view.alpha = 1
        }, completion: nil)
}

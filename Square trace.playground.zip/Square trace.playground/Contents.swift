
import UIKit
import PlaygroundSupport

let backgroundView = UIView()
backgroundView.backgroundColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)

PlaygroundPage.current.liveView = backgroundView
let a = PlaygroundPage.current.liveView.debugDescription

let livePageScreenCompactSize = CGSize(width: 432, height: 569)
let livePageScreenFullSize = CGSize(width: 1000, height: 569)
let livePageCenter = CGPoint(x:livePageScreenCompactSize.width/2, y: livePageScreenCompactSize.height/2)

class AnimationSquareView: UIView { 
    let square = UIView(frame: CGRect(origin: CGPoint(x:0, y: 0), size: CGSize(width: 50, height: 50)))
    let animator = UIViewPropertyAnimator(duration: 1, timingParameters: UICubicTimingParameters(animationCurve: .easeInOut))
    let traceLayer = CAShapeLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setup()
    }

    required init?(coder aDecoder: NSCoder){ fatalError("init(coder:) has not been implemented")}
    
    func setup() {
        square.backgroundColor = #colorLiteral(red: 0.466666668653488, green: 0.764705896377563, blue: 0.266666680574417, alpha: 1.0)
        addSubview(square)
        setupTrace()
        let link = CADisplayLink(target: self, selector: #selector(AnimationSquareView.updateTrace))
        link.add(to: RunLoop.main(), forMode: RunLoopMode.defaultRunLoopMode.rawValue)
    }
    
    func setupTrace() {
        traceLayer.frame = bounds
        traceLayer.strokeColor = UIColor.gray().cgColor
        traceLayer.fillColor = UIColor.clear().cgColor
        let path = UIBezierPath()
        path.move(to: square.center)
        traceLayer.path = path.cgPath
        layer.addSublayer(traceLayer)
    }
    
    func updateTrace() {
        guard let path = traceLayer.path, 
         let presentation = square.layer.presentation() else { return }
        let bezier = UIBezierPath(cgPath: path)
        bezier.addLine(to: presentation.position)
        traceLayer.path = bezier.cgPath
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        addSpot(location: touch.location(in: self))
        animator.addAnimations{
            self.square.center = touch.location(in: self)
        }
        if animator.isRunning{ return }
        animator.startAnimation()
        animator.addCompletion{_ in
            self.removeLine()
        }
    }
    
    func addSpot(location: CGPoint){
        let spotDiameter: CGFloat = 15
        let spot = UIView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: CGSize(width: spotDiameter, height: spotDiameter)))
        spot.layer.cornerRadius = spotDiameter/2
        spot.backgroundColor = #colorLiteral(red: 0.745098054409027, green: 0.156862750649452, blue: 0.0745098069310188, alpha: 1.0).withAlphaComponent(0.3)
        spot.center = location
        addSubview(spot)
        removeSpot(spot: spot)
    }
    
    func removeSpot(spot: UIView){
        UIView.animate(withDuration: 0.2, animations: {
            spot.transform = CGAffineTransform(scaleX: 2, y: 2)
            spot.alpha = 0.0
        }){_ in
            spot.removeFromSuperview()
        }
    }
    
    func removeLine(){
        
    }
}

let squareView = AnimationSquareView(frame: CGRect(origin: CGPoint(x: 0, y: 0), size: livePageScreenFullSize))
backgroundView.addSubview(squareView)

